/*
	Object name:		00000_PRE_DeploymentScripts.sql
	Object type:		Pre-Deployment Script
    Description:        All Scripts taht need to be executed PRIOR 
						to the deployment.
*/
:r .\00001_PRE_SystemViewsToTables.sql