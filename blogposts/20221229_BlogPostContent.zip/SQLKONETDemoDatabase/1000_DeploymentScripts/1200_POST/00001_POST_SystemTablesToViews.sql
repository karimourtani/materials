/*
	Object name:		00001_POST_SystemTablesToViews.sql
	Object type:		Post-Deployment Script
    Description:        Drops the table that exist 
						and convert them to a view.
	Version history:	
		2022-12-28:		Initial Inclusion
*/
IF EXISTS
(
    SELECT object_id
    FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[so].[Columns]')
          AND type IN ( N'U' )
)
BEGIN
    DROP TABLE [so].[Columns];
END;
GO
IF EXISTS
(
    SELECT object_id
    FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[so].[Columns]')
          AND type IN ( N'V' )
)
BEGIN

    DROP VIEW [so].[Columns];
END;
GO

IF EXISTS
(
    SELECT object_id
    FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[so].[Types]')
          AND type IN ( N'U' )
)
BEGIN
    DROP TABLE [so].[Types];
END;
GO
IF EXISTS
(
    SELECT object_id
    FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[so].[Types]')
          AND type IN ( N'V' )
)
BEGIN

    DROP VIEW [so].[Types];
END;
GO

CREATE VIEW [so].[Columns]
AS
SELECT object_id,
       name,
       column_id,
       system_type_id,
       user_type_id,
       max_length,
       precision,
       scale,
       collation_name,
       is_nullable,
       is_ansi_padded,
       is_rowguidcol,
       is_identity,
       is_computed,
       is_filestream,
       is_replicated,
       is_non_sql_subscribed,
       is_merge_published,
       is_dts_replicated,
       is_xml_document,
       xml_collection_id,
       default_object_id,
       rule_object_id,
       is_sparse,
       is_column_set,
       generated_always_type,
       generated_always_type_desc,
       encryption_type,
       encryption_type_desc,
       encryption_algorithm_name,
       column_encryption_key_id,
       column_encryption_key_database_name,
       is_hidden,
       is_masked,
       graph_type,
       graph_type_desc
FROM sys.columns;
GO
CREATE VIEW [so].[Types]
AS
SELECT name,
       system_type_id,
       user_type_id,
       schema_id,
       principal_id,
       max_length,
       precision,
       scale,
       collation_name,
       is_nullable,
       is_user_defined,
       is_assembly_type,
       default_object_id,
       rule_object_id,
       is_table_type
FROM sys.types;
GO

