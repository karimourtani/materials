/*
	Object name:		00000_POST_DeploymentScripts.sql
	Object type:		Post-Deployment Script
    Description:        All Scripts that need to be executed AFTER 
						to the deployment.
*/
:r .\00001_POST_SystemTablesToViews.sql