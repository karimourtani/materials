﻿/*
	Object name:		so
	Object type:		Schema
	Description:		
	
	Version history:	
		2022-12-28:		Initial inclusion.
*/

CREATE SCHEMA so;
GO
