﻿/*
	Object name:		dbo.usp_GetColumnInformation
	Object Type:		Stored Procedure
	Version history:	
		2022-12-28:		Initial Inclusion
*/

CREATE PROCEDURE dbo.usp_GetColumnInformation @TableName NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT x.ObjectSchemaName,
           x.ObjectName,
           x.ObjectFullName,
           x.ColumnName,
           x.ColumntypeName
    FROM
    (
        SELECT OBJECT_SCHEMA_NAME(c.object_id) AS ObjectSchemaName,
               OBJECT_NAME(c.object_id) AS ObjectName,
               OBJECT_SCHEMA_NAME(c.object_id) + '.' + OBJECT_NAME(c.object_id) AS ObjectFullName,
               c.name AS ColumnName,
               t.name AS ColumntypeName,
               c.column_id AS ColumnOrder
        FROM so.Columns c
            JOIN so.Types t
                ON c.system_type_id = t.system_type_id
        WHERE c.object_id = OBJECT_ID(@TableName)
    ) x
    ORDER BY x.ColumnOrder ASC;

    RETURN 0; --SUCCESS
END;
GO


