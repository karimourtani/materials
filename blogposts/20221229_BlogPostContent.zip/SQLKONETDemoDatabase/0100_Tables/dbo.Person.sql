﻿/*
	Object name:		dbo.Person
	Object type:		Table
    Description:        All People in the application
	Version history:	
		2022-12-28:		Initial Inclusion
*/

CREATE TABLE dbo.Person
(
    ID INT IDENTITY(1, 1) NOT NULL,
    Active TINYINT NOT NULL,
    Created DATETIME NOT NULL,
    CreatedBy NVARCHAR(254) NOT NULL,
    Modified DATETIME NOT NULL,
    ModifiedBy NVARCHAR(254) NOT NULL,
    Deleted DATETIME NULL,
    DeletedBy NVARCHAR(254) NULL,
    [Version] INT NOT NULL,
    [ParentId] INT NOT NULL,
    [Name] NVARCHAR(254) NOT NULL,
    CONSTRAINT [PK_DBO_PERSON]
        PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO

ALTER TABLE dbo.Person ADD CONSTRAINT [DF_DBO_PERSON_ACTIVE] DEFAULT (1) FOR Active;
GO

ALTER TABLE dbo.Person ADD CONSTRAINT [DF_DBO_PERSON_CREATED] DEFAULT (GETDATE()) FOR Created;
GO

ALTER TABLE dbo.Person ADD CONSTRAINT [DF_DBO_PERSON_CREATEDBY] DEFAULT ('Unknown') FOR CreatedBy;
GO

ALTER TABLE dbo.Person ADD CONSTRAINT [DF_DBO_PERSON_MODIFIED] DEFAULT (GETDATE()) FOR Modified;
GO

ALTER TABLE dbo.Person ADD CONSTRAINT [DF_DBO_PERSON_MODIFIEDBY] DEFAULT ('Unknown') FOR ModifiedBy;
GO

ALTER TABLE dbo.Person ADD CONSTRAINT [DF_DBO_PERSON_VERSION] DEFAULT (1) FOR [Version];
GO

