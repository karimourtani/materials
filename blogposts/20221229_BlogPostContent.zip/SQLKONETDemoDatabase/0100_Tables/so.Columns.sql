﻿/*
	Object name:		so.Columns
	Object type:		Table
    Description:        A Table that reflecs the system table sys.columns
	Version history:	
		2022-12-28:		Initial Inclusion
*/

CREATE TABLE [so].[Columns]
(
	[object_id] [INT] NOT NULL,
	[name] [sysname] NULL,
	[column_id] [INT] NOT NULL,
	[system_type_id] [TINYINT] NOT NULL,
	[user_type_id] [INT] NOT NULL,
	[max_length] [SMALLINT] NOT NULL,
	[precision] [TINYINT] NOT NULL,
	[scale] [TINYINT] NOT NULL,
	[collation_name] [sysname] NULL,
	[is_nullable] [BIT] NULL,
	[is_ansi_padded] [BIT] NOT NULL,
	[is_rowguidcol] [BIT] NOT NULL,
	[is_identity] [BIT] NOT NULL,
	[is_computed] [BIT] NOT NULL,
	[is_filestream] [BIT] NOT NULL,
	[is_replicated] [BIT] NULL,
	[is_non_sql_subscribed] [BIT] NULL,
	[is_merge_published] [BIT] NULL,
	[is_dts_replicated] [BIT] NULL,
	[is_xml_document] [BIT] NOT NULL,
	[xml_collection_id] [INT] NOT NULL,
	[default_object_id] [INT] NOT NULL,
	[rule_object_id] [INT] NOT NULL,
	[is_sparse] [BIT] NULL,
	[is_column_set] [BIT] NULL,
	[generated_always_type] [TINYINT] NULL,
	[generated_always_type_desc] [NVARCHAR](60) NULL,
	[encryption_type] [INT] NULL,
	[encryption_type_desc] [NVARCHAR](64) NULL,
	[encryption_algorithm_name] [sysname] NULL,
	[column_encryption_key_id] [INT] NULL,
	[column_encryption_key_database_name] [sysname] NULL,
	[is_hidden] [BIT] NULL,
	[is_masked] [BIT] NOT NULL,
	[graph_type] [INT] NULL,
	[graph_type_desc] [NVARCHAR](60) NULL
) 
GO