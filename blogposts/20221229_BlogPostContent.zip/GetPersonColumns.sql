DECLARE @TableName sysname = 'dbo.Person';

SELECT	x.ObjectSchemaName
	  , x.ObjectName
	  , x.ObjectFullName
	  , x.ColumnName
	  , x.ColumntypeName
FROM
		(
			SELECT	OBJECT_SCHEMA_NAME(c.object_id)									 AS ObjectSchemaName
				  , OBJECT_NAME(c.object_id)										 AS ObjectName
				  , OBJECT_SCHEMA_NAME(c.object_id) + '.' + OBJECT_NAME(c.object_id) AS ObjectFullName
					--, c.object_id
				  , c.name															 AS ColumnName
				  , t.name															 AS ColumntypeName
				  , c.column_id														 AS ColumnOrder
			FROM	sys.columns c
			JOIN	sys.types	t ON c.system_type_id = t.system_type_id
			WHERE
					c.object_id = OBJECT_ID(@TableName)
		) x
ORDER BY
		x.ColumnOrder ASC;
