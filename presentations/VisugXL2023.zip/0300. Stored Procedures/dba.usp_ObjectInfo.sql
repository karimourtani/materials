/*
	Object name:		dba.usp_ObjectInfo
	Object Type:		Stored Procedure
	Version history:	
		2023-02-01:		Initial Inclusion
*/
CREATE PROCEDURE dba.usp_ObjectInfo
	@SourceName NVARCHAR(254)
  , @ShowResult BIT = NULL
  , @ObjectId INT = NULL OUTPUT
  , @ObjectSchemaName NVARCHAR(254) = NULL OUTPUT
  , @ObjectName NVARCHAR(254) = NULL OUTPUT
  , @ObjectFullName NVARCHAR(254) = NULL OUTPUT
  , @ObjectTagName NVARCHAR(254) = NULL OUTPUT
AS
BEGIN
	SET NOCOUNT ON ;
	DECLARE @Message NVARCHAR(4000) = N'' ;

	SET @ShowResult = ISNULL(@ShowResult, 0) ;
	SET @ObjectId = OBJECT_ID(@SourceName) ;
	IF (@ObjectId IS NULL)
	BEGIN
		SET @Message = N'Could not find object "' + @SourceName + N'".' ;
		RAISERROR(@Message, 16, 1) ;
		RETURN 1 ;
	END ;
	SET @ObjectSchemaName = OBJECT_SCHEMA_NAME(@ObjectId) ;
	SET @ObjectName = OBJECT_NAME(@ObjectId) ;
	SET @ObjectFullName = @ObjectSchemaName + N'.' + @ObjectName ;
	SET @ObjectTagName = UPPER(@ObjectSchemaName + '_' + @ObjectName) ;
	IF (@ShowResult = 1)
	BEGIN
		SELECT
			@SourceName AS SourceName
		  , @ObjectId AS ObjectId
		  , @ObjectSchemaName AS ObjectSchemaName
		  , @ObjectName AS ObjectName
		  , @ObjectFullName AS ObjectFullName
		  , @ObjectTagName AS ObjectTagName ;
	END ;
	RETURN 0 ;
END ;
GO