/*
	Object name:		[dba].[usp_MigrationRemove]
	Object Type:		Stored Procedure
	Version history:	
		2023-02-01:		Initial Inclusion
*/

CREATE PROCEDURE [dba].[usp_MigrationRemove] @MigrationId NVARCHAR(254) = NULL
AS
BEGIN
	SET NOCOUNT ON ;
	DECLARE @Message NVARCHAR(MAX) ;
	DECLARE @IntValue INT ;
	IF (ISNULL(@MigrationId, '') = '')
	BEGIN
		DECLARE @TBL AS TABLE
		(
			Id INT IDENTITY(1, 1) NOT NULL
		  , [MigrationId] NVARCHAR(254) NULL
		) ;
		INSERT INTO @TBL
		(
			[MigrationId]
		)
		SELECT
					[MigrationId]
		FROM		[dba].[Migration]
		ORDER BY	Id ASC ;
		SET @IntValue =
		(
			SELECT COUNT(Id)FROM @TBL
		) ;
		WHILE (@IntValue > 0)
		BEGIN
			SELECT		TOP (1)
						@IntValue = Id
					  , @Message = MigrationId
			FROM		@TBL
			ORDER BY	Id ASC ;
			--  EXEC dba.usp_MigrationRemove @MigrationId = N'' -- nvarchar(254)
			SET @Message  = 'EXEC dba.usp_MigrationRemove @MigrationId = N''' + @Message + ''';';
			PRINT @Message ;
			DELETE	FROM @TBL
			WHERE	Id = @IntValue ;
			SET @IntValue =
			(
				SELECT COUNT(Id)FROM @TBL
			) ;
		END ;
		RETURN 0 ;
	END ;
	DELETE	FROM [dba].[Migration]
	WHERE	[MigrationId] = @MigrationId ;

	SET @Message = N'Migration with ID "' + @MigrationId + N'" has been removed.' ;
	PRINT @Message ;

	RETURN 0 ;
END ;
GO

