﻿/*
	Object name:		[udf].[Environment]
	Object type:		Function
	Description:		Returns the name of the environment, based on machine name.
	
	Version history:	
		2023-11-30:		First version
*/

CREATE FUNCTION [udf].[Environment]
()
RETURNS NVARCHAR(10)
AS
BEGIN
	DECLARE @res AS NVARCHAR(10) = N'UNKNOWN';
	DECLARE @server AS NVARCHAR(50) = @@SERVERNAME;
	SET @res =
		(
			SELECT
				TOP (1)
				CASE
					WHEN @server = 'MARVIN' THEN 'DEV'
					WHEN @server = 'MARVIN\CHICAGO' THEN 'CHI'
					WHEN @server = 'MARVIN\NEWYORK' THEN 'NY'
					WHEN @server = 'MARVIN\DC' THEN 'DC'
					ELSE 'UNKNOWN'
				END AS ENV
			ORDER BY
				ENV
		);
	RETURN @res;
END;
GO