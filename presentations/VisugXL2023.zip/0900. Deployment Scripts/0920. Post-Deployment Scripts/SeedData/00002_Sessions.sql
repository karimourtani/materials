/*
	Object name:		SeedData-Session
	Object Type:		Post-deployment Script - SeedData
	Every deploy?:		YES
	Version history:			
		2023-11-30:		FIrst version
*/
BEGIN -- GENERAL DECLARATIONS    
	DECLARE @NU DATETIME= GETDATE();
	DECLARE @Actor NVARCHAR(254) = 'SeedData-Session';
	DECLARE @Active TINYINT = 1;
	DECLARE @Version INT = 1;
END

BEGIN
    EXEC dba.usp_PrintMessage @Value1 = N'START', @Value2 = @Actor
END
BEGIN -- SCRIPT SPECIFIC DECLARATIONS

    DECLARE @Message NVARCHAR(MAX);
    DECLARE @Count INT;
	DECLARE @TBL AS TABLE
	(
		 [Title]				   NVARCHAR(254)
		
	);

END
BEGIN -- SET SCRIPT SPECIFIC VALUES
    
	INSERT INTO @TBL ([Title])
VALUES
  ('Vangeel') ,
  ('Tech interviews: what about them and how to ace them?')
, ('Build Your .NET Docker Containers the Correct Way')
, ('A Deep Dive into Microsoft Accessibility Insights for Web')
, ('.NET MAUI Blazor - Build Hybrid Mobile, Desktop, and Web apps')
, ('What the container')
, ('Applying effective Source Control to your Database System')
, ('From Hell to Heaven: Porting Doom to MAUI')
, ('Well-Balanced Test-Driven Development')
, ('A Trip Down Memory(Of T) Lane')
, ('Demystifying Azure app service''s performance and scaling')
, ('GraphQL at scale with Azure and .NET: stories from the trenches!')
, ('Tighten your Nuget packages')
, ('Celebrity Deathmatch: Akka.NET vs Orleans')
, ('Don''t Trust the Browser: Secure SPAs with BFF')
, ('Everything a .NET developer needs to know about configuration and secret management')

END
BEGIN -- MERGE STATEMENT  
 
	MERGE [dbo].[Session] AS TargetTable
	USING @TBL AS SourceTable
	ON (SourceTable.[Title] = TargetTable.[Title])
	-- INSERT
	WHEN NOT MATCHED BY TARGET THEN
		INSERT
			           ([Active] ,[Version] ,[Created] ,[CreatedBy]
           ,[Title])
		VALUES
		           (@Active ,@Version ,@NU ,@Actor 
           ,SourceTable.[Title] )
	-- UPDATE
	WHEN MATCHED THEN
		UPDATE SET TargetTable.[Title] = SourceTable.[Title]
					, TargetTable.Modified = @NU
					, TargetTable.ModifiedBy = @Actor					
					, TargetTable.Deleted = NULL
					, TargetTable.DeletedBy = NULL
	-- DELETE (SOFT)
	WHEN NOT MATCHED BY SOURCE THEN UPDATE SET TargetTable.Deleted = @NU
												, TargetTable.DeletedBy = @Actor;
					

END
BEGIN
    EXEC dba.usp_PrintMessage @Value1 = N'STOP', @Value2 = @Actor;
END
GO