﻿/*

	Object name:		[dba]
	Object type:		Schema
	Description:		A Schema for all DBA related stuff.
	
	Version history:	
		2023-02-01:		Initial inclusion.

*/
CREATE SCHEMA [dba];
GO
