﻿/*

	Object name:		[tools]
	Object type:		Schema
	Description:		A Schema for all tools.
	
	Version history:	
		2023-02-01:		Initial inclusion.

*/
CREATE SCHEMA [tools];
GO
