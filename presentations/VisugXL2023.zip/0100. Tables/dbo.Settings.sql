﻿/*

	Object name:		[dbo].[Settings]
	Object type:		Table
	Description:		A table with all the settings.
	
	Version history:	
		2023-11-30:		Initial inclusion.

*/
/*

	Object name:		[dbo].[Settings]
	Object type:		Table
	Description:		A table with all the settings.
	
	Version history:	
		2023-11-30:		Initial inclusion.

*/
CREATE TABLE [dbo].[Settings]
    (
        [Id]           [INT]           NOT NULL
      , [Version]      [INT]           NOT NULL
      , [Created]      [DATETIME]      NOT NULL
      , [CreatedBy]    [NVARCHAR](254) NOT NULL
      , [ReleaseId]    [NVARCHAR](254) NULL
      , [ReleaseStart] [DATETIME]      NULL
      , [ReleaseEnd]   [DATETIME]      NULL
      , CONSTRAINT [PK_DBO_SETTINGS]
            PRIMARY KEY CLUSTERED ([Id] ASC)
    );
GO


ALTER TABLE [dbo].[Settings]
ADD
    CONSTRAINT [DF_DBO_SETTINGS_ID]
    DEFAULT (0) FOR Id;
GO
ALTER TABLE [dbo].[Settings]
ADD
    CONSTRAINT [DF_DBO_SETTINGS_VERSION]
    DEFAULT (1) FOR [Version];
GO
ALTER TABLE [dbo].[Settings]
ADD
    CONSTRAINT [DF_DBO_SETTINGS_CREATED]
    DEFAULT (GETDATE()) FOR [Created];
GO
ALTER TABLE [dbo].[Settings]
ADD
    CONSTRAINT [DF_DBO_SETTINGS_CREATEDBY]
    DEFAULT ('Unknown') FOR [CreatedBy];
GO
ALTER TABLE [dbo].[Settings]
ADD
    CONSTRAINT [UC_DBO_SETTINGS]
    UNIQUE (Id);
GO
ALTER TABLE [dbo].[Settings]
ADD
    CONSTRAINT [CK_DBO_SETTINGS] 
    CHECK (Id = 0);
GO