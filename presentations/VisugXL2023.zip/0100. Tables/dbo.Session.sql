﻿/*

	Object name:		[dbo].[Session]
	Object type:		Table
	Description:		A table that Lists all counties.
	
	Version history:	
		2023-11-30:		Initial inclusion.

*/


CREATE TABLE [dbo].[Session]
    (
        [Id]         [INT]          IDENTITY(1, 1) NOT NULL
      , [Active]     TINYINT        CONSTRAINT [DF_DBO_SESSION_ACTIVE] DEFAULT (1) NOT NULL
      , [Version]    INT            CONSTRAINT [DF_DBO_SESSION_VERSION] DEFAULT (1) NOT NULL
      , [Created]    DATETIME       CONSTRAINT [DF_DBO_SESSION_CREATED] DEFAULT (GETDATE()) NOT NULL
      , [CreatedBy]  NVARCHAR(254)  CONSTRAINT [DF_DBO_SESSION_CREATEDBY] DEFAULT ('Unknown') NOT NULL
      , [Modified]   DATETIME       NULL
      , [ModifiedBy] NVARCHAR(254)  NULL
      , [Deleted]    DATETIME       NULL
      , [DeletedBy]  NVARCHAR(254)  NULL
      , [Title]      NVARCHAR(254)  NULL
      , [Lastname]   NVARCHAR(254)  NULL
      , CONSTRAINT [PK_DBO_SESSION]
            PRIMARY KEY CLUSTERED ([Id] ASC)
    );
GO