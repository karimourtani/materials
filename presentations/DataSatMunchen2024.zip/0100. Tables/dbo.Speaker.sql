﻿/*

	Object name:		[dbo].[Speaker]
	Object type:		Table
	Description:		A table that Lists all counties.
	
	Version history:	
		2023-11-30:		Initial inclusion.

*/


CREATE TABLE [dbo].[Speaker]
    (
        [Id]         [INT]          IDENTITY(1, 1) NOT NULL
      , [Active]     TINYINT            CONSTRAINT [DF_DBO_SPEAKER_ACTIVE] DEFAULT (1) NOT NULL
      , [Version]    INT                CONSTRAINT [DF_DBO_SPEAKER_VERSION] DEFAULT (1) NOT NULL
      , [Created]    DATETIME           CONSTRAINT [DF_DBO_SPEAKER_CREATED] DEFAULT (GETDATE()) NOT NULL
      , [CreatedBy]  NVARCHAR(254)      CONSTRAINT [DF_DBO_SPEAKER_CREATEDBY] DEFAULT ('Unknown') NOT NULL
      , [Modified]   DATETIME           NULL
      , [ModifiedBy] NVARCHAR(254)      NULL
      , [Deleted]    DATETIME           NULL
      , [DeletedBy]  NVARCHAR(254)      NULL
      , [Code]       UNIQUEIDENTIFIER   CONSTRAINT [DF_DBO_SPEAKER_CODE] DEFAULT (NEWID()) NOT NULL
      , [Firstname]  NVARCHAR(254)      NULL
      , [Lastname]   NVARCHAR(254)      NULL
      , CONSTRAINT [PK_DBO_SPEAKER]
            PRIMARY KEY CLUSTERED ([Id] ASC)
    );
GO