/*
	Object name:		dba.usp_SettingRemove
	Object Type:		Stored Procedure
	Version history:	
		2023-02-01:		Initial Inclusion
*/

CREATE PROCEDURE dba.usp_SettingRemove
	@Name NVARCHAR(254) = NULL
  , @Actor NVARCHAR(254) = NULL
  , @ID INT = 0 OUTPUT
AS
BEGIN
	SET NOCOUNT ON ;
	DECLARE @Message NVARCHAR(MAX) = '';
	DECLARE @IntValue INT = 0;
	SET @Name = UPPER(@Name) ;
	IF (ISNULL(@Actor, '') = '')
	BEGIN
		SET @Actor = 'Unknown' ;
	END ;

	IF (ISNULL(@Name, '') = '')
	BEGIN
		DECLARE @TBL AS TABLE
		(
			ID INT IDENTITY(1, 1) NOT NULL
		  , ValueString NVARCHAR(254) NULL
		) ;
		INSERT INTO @TBL
		(
			ValueString
		)
		SELECT
					[Name]
		FROM		[dba].Setting
		ORDER BY	ID ASC ;
		SET @IntValue =
		(
			SELECT COUNT(ID)FROM @TBL
		) ;
		WHILE (@IntValue > 0)
		BEGIN
			SELECT		TOP (1)
						@IntValue = ID
					  , @Message = ValueString
			FROM		@TBL
			ORDER BY	ID ASC ;
			SET @Message  = 'EXEC dba.usp_SettingRemove @Name = N''' + @Message + ''';';
			PRINT @Message ;
			DELETE	FROM @TBL
			WHERE	ID = @IntValue ;
			SET @IntValue =
			(
				SELECT COUNT(ID)FROM @TBL
			) ;
		END ;
		RETURN 0 ;
	END ;










	SET @ID =
	(
		SELECT		TOP (1)
					ID
		FROM		dba.Setting
		WHERE		Active = 1
					AND [Name] = @Name
		ORDER BY	ID ASC
	) ;
	IF (@ID IS NULL)
	BEGIN
		SET @ID =
	(
		SELECT		TOP (1)
					ID
		FROM		dba.Setting
		WHERE		Active = 0
					AND [Name] = @Name
		ORDER BY	ID ASC
	) ;
	IF (@ID IS NULL)
	BEGIN
		SET @Message = N'Could not find setting "' + @Name + N'".' ;
		PRINT @Message;
	END 
	ELSE
	BEGIN
		SET @Message = N'Setting "' + @Name + N'" has already been soft-deleted..' ;
		PRINT @Message;
	END 

	END ;
	ELSE
	BEGIN
		UPDATE
				dba.Setting
		SET
				Active = 0
			  , [Version] = [Version] + 1
			  , Deleted = GETDATE()
			  , DeletedBy = @Actor
		WHERE	ID = @ID ;
		
		SET @Message = N'Setting "' + @Name + N'" has been soft-deleted.' ;
		PRINT @Message;
	END ;
	RETURN 0 ;
END ;
GO
