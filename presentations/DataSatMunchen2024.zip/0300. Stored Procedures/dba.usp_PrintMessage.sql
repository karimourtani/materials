/*
	Object name:		dba.usp_PrintMessage
	Object type:		Stored Procedure
	Description:		
	
	Version history:	
		2023-11-30:		FIrst version.
*/

CREATE PROCEDURE [dba].[usp_PrintMessage]
	@Value1 NVARCHAR(MAX) = NULL
  , @Value2 NVARCHAR(MAX) = NULL
  , @Value3 NVARCHAR(MAX) = NULL
  , @Value4 NVARCHAR(MAX) = NULL
  , @Value5 NVARCHAR(MAX) = NULL
  , @Value6 NVARCHAR(MAX) = NULL
  , @Value7 NVARCHAR(MAX) = NULL
  , @Value8 NVARCHAR(MAX) = NULL
  , @Value9 NVARCHAR(MAX) = NULL
AS
BEGIN
	DECLARE @Message NVARCHAR(MAX);
	IF (
		   (@Value1 = '*')
		   AND	(@Value2 IS NULL)
		   AND	(@Value3 IS NULL)
		   AND	(@Value4 IS NULL)
		   AND	(@Value5 IS NULL)
		   AND	(@Value6 IS NULL)
		   AND	(@Value7 IS NULL)
		   AND	(@Value8 IS NULL)
		   AND	(@Value9 IS NULL)
	   )
	BEGIN
		SET @Message
			= N'/********************************************************************************************/';
		PRINT @Message;
		RETURN;
	END;
	IF (
		   (UPPER (@Value1) IN ( 'START', 'END', 'STOP' ))
		   AND	(@Value2 IS NOT NULL)
		   AND	(@Value3 IS NULL)
		   AND	(@Value4 IS NULL)
		   AND	(@Value5 IS NULL)
		   AND	(@Value6 IS NULL)
		   AND	(@Value7 IS NULL)
		   AND	(@Value8 IS NULL)
		   AND	(@Value9 IS NULL)
	   )
	BEGIN
		SET @Message
			= N'/********************************************************************************************/';
		PRINT @Message;
		SET @Message
			= CONCAT (@Value2, ': ', UPPER (@Value1), ' (', FORMAT (GETDATE (), 'yyyy-MM-dd HH:mm:ss.fff'), ')');
		PRINT @Message;
		SET @Message
			= N'/********************************************************************************************/';
		PRINT @Message;
		RETURN;
	END;

	IF (
		   (@Value1 = '*')
		   AND	(@Value3 = '*')
		   AND	(@Value4 IS NULL)
		   AND	(@Value5 IS NULL)
		   AND	(@Value6 IS NULL)
		   AND	(@Value7 IS NULL)
		   AND	(@Value8 IS NULL)
		   AND	(@Value9 IS NULL)
	   )
	BEGIN
		IF (@Value2 IS NULL)
		BEGIN
			SET @Value2 = 'NULL';
		END;
		SET @Message
			= N'/********************************************************************************************/';
		PRINT @Message;
		PRINT @Value2;
		PRINT @Message;
		RETURN;
	END;


	IF (
		   (@Value1 IS NULL)
		   AND	(@Value2 IS NULL)
		   AND	(@Value3 IS NULL)
		   AND	(@Value4 IS NULL)
		   AND	(@Value5 IS NULL)
		   AND	(@Value6 IS NULL)
		   AND	(@Value7 IS NULL)
		   AND	(@Value8 IS NULL)
		   AND	(@Value9 IS NULL)
	   )
	BEGIN
		SET @Message = N'';
		PRINT @Message;
		RETURN;
	END;
	ELSE
	BEGIN

		IF (
			   (@Value1 IS NOT NULL)
			   AND	(@Value2 IS NOT NULL)
			   AND	(@Value3 IS NULL)
			   AND	(@Value4 IS NULL)
			   AND	(@Value5 IS NULL)
			   AND	(@Value6 IS NULL)
			   AND	(@Value7 IS NULL)
			   AND	(@Value8 IS NULL)
			   AND	(@Value9 IS NULL)
		   )
		BEGIN
			SET @Message = @Value1 + N': ' + @Value2;
			PRINT @Message;
		END;
		ELSE
		BEGIN

			PRINT @Value1;
			IF (@Value2 IS NOT NULL)
			BEGIN
				PRINT @Value2;
			END;

			IF (@Value3 IS NOT NULL)
			BEGIN
				PRINT @Value3;
			END;

			IF (@Value4 IS NOT NULL)
			BEGIN
				PRINT @Value4;
			END;

			IF (@Value5 IS NOT NULL)
			BEGIN
				PRINT @Value5;
			END;

			IF (@Value6 IS NOT NULL)
			BEGIN
				PRINT @Value6;
			END;

			IF (@Value7 IS NOT NULL)
			BEGIN
				PRINT @Value7;
			END;

			IF (@Value8 IS NOT NULL)
			BEGIN
				PRINT @Value8;
			END;

			IF (@Value9 IS NOT NULL)
			BEGIN
				PRINT @Value9;
			END;
		END;

	END;
END;
GO

