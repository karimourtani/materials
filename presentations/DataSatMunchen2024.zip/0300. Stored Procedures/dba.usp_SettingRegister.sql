/*
	Object name:		dba.usp_SettingRegister
	Object Type:		Stored Procedure
	Version history:	
		2023-02-01:		Initial Inclusion
*/

CREATE PROCEDURE dba.usp_SettingRegister
	@Name NVARCHAR(254)
  , @Value NVARCHAR(MAX)
  , @Actor NVARCHAR(254) = NULL
  , @ID INT = 0 OUTPUT
AS
BEGIN
	SET NOCOUNT ON ;
	DECLARE @Message NVARCHAR(MAX) ;
	IF (ISNULL(@Actor, '') = '')
	BEGIN
		SET @Actor = 'Unknown' ;
	END ;
	SET @Name = UPPER(@Name);

	SET @ID =
	(
		SELECT		TOP (1)
					ID
		FROM		dba.Setting
		WHERE		Active = 1
					AND [Name] = @Name
		ORDER BY	ID ASC
	) ;
	IF (@ID IS NULL)
	BEGIN
		INSERT INTO dba.Setting
		(
			Active
		  , [Version]
		  , Created
		  , CreatedBy
		  , [Name]
		  , [Value]
		)
		SELECT
			1
		  , 1
		  , GETDATE()
		  , @Actor
		  , @Name
		  , @Value ;
		SET @ID = SCOPE_IDENTITY() ;
		SET @Message = N'Setting "' + @Name + N'" has been ADDED.' ;
		PRINT @Message;
	END ;
	ELSE
	BEGIN
		UPDATE
				dba.Setting
		SET
				[Version] = [Version] + 1
			  , Modified = GETDATE()
			  , ModifiedBy = @Actor
			  , [Value] = @Value
		WHERE	ID = @ID ;
		SET @Message = N'Setting "' + @Name + N'" has been UPDATED.' ;
		PRINT @Message;

	END ;
	RETURN 0 ;
END ;
GO
