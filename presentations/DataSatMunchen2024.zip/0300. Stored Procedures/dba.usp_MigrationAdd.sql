/*
	Object name:		[dba].[usp_MigrationAdd]
	Object Type:		Stored Procedure
	Version history:	
		2023-02-01:		Initial Inclusion
		2023-02-24:		dded new column See ID 256978
*/

CREATE PROCEDURE [dba].[usp_MigrationAdd]
	@MigrationId NVARCHAR(254)
  , @CreatedBy NVARCHAR(254) = NULL
AS
BEGIN
	SET NOCOUNT ON ;
	DECLARE @Message NVARCHAR(MAX) ;
	IF (@CreatedBy IS NULL)
	BEGIN
		SET @CreatedBy = 'Migration of ' + udf.DateTimeToTag(GETDATE()) ;
	END ;

	INSERT INTO [dba].[Migration]
	(
		[MigrationId]
	  , [Created]
	  , [CreatedBy]
	)
	SELECT
		@MigrationId
	  , GETDATE()
	  , @CreatedBy ;
	SET @Message = N'Migration with ID "' + @MigrationId + N'" has been executed and is registered.' ;
	PRINT @Message ;
	RETURN 0 ;
END ;
GO
