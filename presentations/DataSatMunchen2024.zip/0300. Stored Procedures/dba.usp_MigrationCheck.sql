/*
	Object name:		[dba].[usp_MigrationCheck]
	Object Type:		Stored Procedure
	Version history:	
		2023-02-01:		Initial Inclusion
*/

CREATE PROCEDURE [dba].[usp_MigrationCheck] @MigrationId NVARCHAR(254)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @ID INT = NULL;
    DECLARE @Message NVARCHAR(MAX);
    DECLARE @DateExecuted DATETIME;
     SELECT TOP (1)
               @ID = [Id]
                ,@DateExecuted = [Created]                 
        FROM [dba].[Migration]
        WHERE MigrationId = @MigrationId
        ORDER BY Id ASC


    IF (@ID IS NULL)
    BEGIN
        SET @Message = 'Migration with ID "' + @MigrationId + '" has not yet been executed.';
        PRINT @Message;
        RETURN 0;
    END;
    SET @Message = 'Migration with ID "' + @MigrationId + '" has already been executed on ' + udf.DateTimeToDateTimeString(@DateExecuted) + '.';
        PRINT @Message;
    RETURN 1;
END;
GO