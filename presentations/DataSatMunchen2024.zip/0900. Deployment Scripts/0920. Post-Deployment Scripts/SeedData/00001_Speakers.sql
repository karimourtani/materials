/*
	Object name:		SeedData-Speakers
	Object Type:		Post-deployment Script - SeedData
	Every deploy?:		YES
	Version history:			
		2023-11-30:		FIrst version
*/
BEGIN -- GENERAL DECLARATIONS    
	DECLARE @NU DATETIME= GETDATE();
	DECLARE @Actor NVARCHAR(254) = 'SeedData-Speakers';
	DECLARE @Active TINYINT = 1;
	DECLARE @Version INT = 1;
END

BEGIN
    EXEC dba.usp_PrintMessage @Value1 = N'START', @Value2 = @Actor
END
BEGIN -- SCRIPT SPECIFIC DECLARATIONS

    DECLARE @Message NVARCHAR(MAX);
    DECLARE @Count INT;
	DECLARE @TBL AS TABLE
	(
		  [Code]					UNIQUEIDENTIFIER NOT NULL
		, [Firstname]				   NVARCHAR(254)
		, [Lastname]				   NVARCHAR(254)
	);

END
BEGIN -- SET SCRIPT SPECIFIC VALUES
    
	INSERT INTO @TBL ([Code], [Firstname], [Lastname])
VALUES
('86516100-850E-448E-A436-04B809CBABFA','Wolfgang','Strasser'),
('068BA363-00FB-4ED7-AA82-7FCEE5D2849C','Tillmann','Eitelberg'),
('9DBD9014-3191-40A5-A945-776D4232D582','Els','van Vessem'),
('628C2CB3-B885-42D2-871A-60C083D51834','Odeta','Jankaitien?'),
('9C25C4A4-D513-4E34-829A-D772C7BC3345','Nikola','Ilic'),
('046F06AD-E725-4FC2-BD0F-B92FFD2A16A2','Frank','Geisler'),
('C26983DC-EB31-474C-9B56-494320C81093','Milos','Radivojevic'),
('02F71320-EE0D-46C9-9EE0-7699C61D386C','Paulina','J?drzejewska'),
('0E800E4E-A6C4-441A-B492-48826E74B016','Elena','Drakulevska'),
('56743608-FD12-439D-930C-45FE6906428F','Constantin','Klein'),
--('0CE680B5-7910-41D1-95FE-1FE2629012A6','Karim','Ourtani'),
('AC4F2AA9-255B-44D0-B7BB-29D66C4ECC5D','Mathias','Thierbach'),
('506B7C15-0851-4F6F-90D6-B278671D8E6E','Brian','B�nk'),
('1A6F9B78-1CDD-4391-83F2-FDE6D53E424C','Lisa','Hoving'),
('1955EE72-E916-4E16-8D07-90FAD33AEB1C','Oliver','Engels'),
('592FAC58-D8F1-4A17-A84F-5B039CC57D13','Rob','Sewell'),
('D90EFB7C-3A46-4F0B-9783-222769B72F2A','Ioannis','Philippides'),
('7B2FD8C8-27A7-4E45-8B97-910D53F2E811','Devang','Shah'),
('A68F63D8-B1EE-4A85-AEE7-4568DA1570F4','Marc','Lelijveld'),
('361DA27A-CC10-4EC7-9765-1D34E44EA8FA','Olivier','Van Steenlandt'),
('F7F460B2-F918-4284-9A9F-DF69D2A714DC','Abhinav','Jayanty')
END
BEGIN -- MERGE STATEMENT  
 
	MERGE [dbo].[Speaker] AS TargetTable
	USING @TBL AS SourceTable
	ON (SourceTable.Code = TargetTable.Code)
	-- INSERT
	WHEN NOT MATCHED BY TARGET THEN
		INSERT
			           ([Active] ,[Version] ,[Created] ,[CreatedBy]
           ,[Code] ,[Firstname] ,[Lastname])
		VALUES
		           (@Active ,@Version ,@NU ,@Actor 
           ,SourceTable.[Code] ,SourceTable.[Firstname] ,SourceTable.[Lastname])
	-- UPDATE
	WHEN MATCHED THEN
		UPDATE SET TargetTable.[Code] = SourceTable.[Code]
					, TargetTable.[Firstname] = SourceTable.[Firstname]
					, TargetTable.[Lastname] = SourceTable.[Lastname]
					, TargetTable.Modified = @NU
					, TargetTable.ModifiedBy = @Actor					
					--, TargetTable.Deleted = NULL
					--, TargetTable.DeletedBy = NULL
	-- DELETE (SOFT)
	WHEN NOT MATCHED BY SOURCE THEN UPDATE SET TargetTable.Deleted = @NU
												, TargetTable.DeletedBy = @Actor;
					

END
BEGIN
    EXEC dba.usp_PrintMessage @Value1 = N'STOP', @Value2 = @Actor;
END
GO