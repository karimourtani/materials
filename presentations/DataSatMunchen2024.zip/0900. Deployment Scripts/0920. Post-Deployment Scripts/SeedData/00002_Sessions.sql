/*
	Object name:		SeedData-Session
	Object Type:		Post-deployment Script - SeedData
	Every deploy?:		YES
	Version history:			
		2023-11-30:		FIrst version
*/
BEGIN -- GENERAL DECLARATIONS    
	DECLARE @NU DATETIME= GETDATE();
	DECLARE @Actor NVARCHAR(254) = 'SeedData-Session';
	DECLARE @Active TINYINT = 1;
	DECLARE @Version INT = 1;
END

BEGIN
    EXEC dba.usp_PrintMessage @Value1 = N'START', @Value2 = @Actor
END
BEGIN -- SCRIPT SPECIFIC DECLARATIONS

    DECLARE @Message NVARCHAR(MAX);
    DECLARE @Count INT;
	DECLARE @TBL AS TABLE
	(
		 [Title]				   NVARCHAR(254)
		
	);

END
BEGIN -- SET SCRIPT SPECIFIC VALUES
    
	INSERT INTO @TBL ([Title])
VALUES

('Successfully collaborate with externals in Power BI') ,
('Talking API with your data: REST, GraphQL and more') ,
('Gestalt: The Jedi Mind Trick of Power BI Design') ,
('Old Name - New CLI - why you should take a look at sqlcmd') ,
('Data Engineering in the era of Microsoft Fabric') ,
('Gender 101') ,
('Demystifying Query Store Plan Forcing') ,
('Professional Developer Experiences in Power BI') ,
('Moneyball: How Data and AI have Revolutionised Analytics in Sports') ,
('Migrating from SSRS to Power BI Paginated Reports') ,
('The Data Warehouse in Fabric') ,
('What my pet python taught me about Data Lakes on Azure') ,
('Power BI "X Files" - 5 things they "forgot" to tell you!') ,
('ADX and the last crusade') ,
('Applying effective Source Control to your Database System')

END
BEGIN -- MERGE STATEMENT  
 
	MERGE [dbo].[Session] AS TargetTable
	USING @TBL AS SourceTable
	ON (SourceTable.[Title] = TargetTable.[Title])
	-- INSERT
	WHEN NOT MATCHED BY TARGET THEN
		INSERT
			           ([Active] ,[Version] ,[Created] ,[CreatedBy]
           ,[Title])
		VALUES
		           (@Active ,@Version ,@NU ,@Actor 
           ,SourceTable.[Title] )
	-- UPDATE
	WHEN MATCHED THEN
		UPDATE SET TargetTable.[Title] = SourceTable.[Title]
					, TargetTable.Modified = @NU
					, TargetTable.ModifiedBy = @Actor					
					, TargetTable.Deleted = NULL
					, TargetTable.DeletedBy = NULL
	-- DELETE (SOFT)
	WHEN NOT MATCHED BY SOURCE THEN UPDATE SET TargetTable.Deleted = @NU
												, TargetTable.DeletedBy = @Actor;
					

END
BEGIN
    EXEC dba.usp_PrintMessage @Value1 = N'STOP', @Value2 = @Actor;
END
GO