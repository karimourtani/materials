

DECLARE  @RC INT
SET @RC = EXEC dba.usp_MigrationCheck @MigrationId = 'DeMo001'
if (@Rc = 0) 
BEGIN
    
    -- UPDATES


    EXEC dba.usp_MigrationAdd 'DeMo001'
END